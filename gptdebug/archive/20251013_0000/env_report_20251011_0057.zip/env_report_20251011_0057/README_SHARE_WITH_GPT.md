Upload this folder with your code so GPT understands your environment.
Includes system info, tool versions, scripts, configs, prisma, masked env & db endpoints, and smoke_test.sh.
