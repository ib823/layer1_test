# SAP MVP Framework - Comprehensive Testing Guide

**Version**: 1.0.0
**Date**: October 13, 2025
**Purpose**: Complete testing procedures for User Acceptance Testing (UAT) and production validation

---

## Table of Contents

1. [User Roles & Permissions](#user-roles--permissions)
2. [Test Environment Setup](#test-environment-setup)
3. [Test Data Preparation](#test-data-preparation)
4. [Module Testing Procedures](#module-testing-procedures)
5. [Integration Testing](#integration-testing)
6. [Security & Access Control Testing](#security--access-control-testing)
7. [Performance Testing](#performance-testing)
8. [Expected Results](#expected-results)
9. [Test Reporting](#test-reporting)

---

## User Roles & Permissions

### 1. System Administrator
**Role ID**: `SystemAdmin`
**Role Collection**: `SAP_MVP_SystemAdmin`

**Permissions**:
- ✅ Full access to all modules
- ✅ Tenant management (create, update, delete)
- ✅ User management
- ✅ System configuration
- ✅ Service discovery and configuration
- ✅ View all audit logs
- ✅ Access to monitoring and health endpoints

**Test User Credentials**:
```
Username: admin@sapmvp.com
Role: SystemAdmin
Tenant: ALL
```

---

### 2. Compliance Manager
**Role ID**: `ComplianceManager`
**Role Collection**: `SAP_MVP_ComplianceManager`

**Permissions**:
- ✅ Access to SoD Control module
- ✅ Access to GDPR compliance features
- ✅ View audit logs for their tenant
- ✅ Run compliance reports
- ✅ Export compliance data
- ❌ Cannot modify system configuration
- ❌ Cannot manage users

**Test User Credentials**:
```
Username: compliance@company.com
Role: ComplianceManager
Tenant: COMP-001
Company Codes: 1000, 2000
```

---

### 3. Finance Manager
**Role ID**: `FinanceManager`
**Role Collection**: `SAP_MVP_FinanceManager`

**Permissions**:
- ✅ Access to Invoice Matching module
- ✅ Access to GL Anomaly Detection module
- ✅ Run financial analyses
- ✅ View and export financial reports
- ✅ Review fraud alerts
- ✅ Resolve invoice discrepancies
- ❌ Cannot access vendor management
- ❌ Cannot access compliance modules

**Test User Credentials**:
```
Username: finance@company.com
Role: FinanceManager
Tenant: COMP-001
Company Codes: 1000
```

---

### 4. Auditor
**Role ID**: `Auditor`
**Role Collection**: `SAP_MVP_Auditor`

**Permissions**:
- ✅ Read-only access to all modules
- ✅ View all reports and dashboards
- ✅ Export audit reports
- ✅ View historical data
- ❌ Cannot execute analyses
- ❌ Cannot modify any data
- ❌ Cannot resolve issues

**Test User Credentials**:
```
Username: auditor@company.com
Role: Auditor
Tenant: COMP-001
Company Codes: ALL
```

---

### 5. Vendor Manager
**Role ID**: `VendorManager`
**Role Collection**: `SAP_MVP_VendorManager`

**Permissions**:
- ✅ Access to Vendor Data Quality module
- ✅ Run vendor quality analyses
- ✅ Review and resolve data quality issues
- ✅ Manage duplicate vendors
- ✅ View vendor master data
- ✅ Export vendor reports
- ❌ Cannot access financial modules
- ❌ Cannot access compliance modules

**Test User Credentials**:
```
Username: vendor.manager@company.com
Role: VendorManager
Tenant: COMP-001
Company Codes: 1000, 2000
```

---

## Test Environment Setup

### Prerequisites

1. **Environment Access**
   ```bash
   # Staging/Test Environment URL
   Web UI: https://sapmvp-test.cfapps.eu10.hana.ondemand.com
   API: https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com
   ```

2. **Database Setup**
   ```bash
   # Verify database is running
   curl https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com/api/health/database

   # Expected response:
   {
     "status": "healthy",
     "database": {
       "connected": true,
       "responseTimeMs": 15,
       "tables": [
         { "table": "Tenant", "status": "ok" },
         { "table": "InvoiceMatchRun", "status": "ok" },
         { "table": "GLAnomalyRun", "status": "ok" },
         { "table": "VendorQualityRun", "status": "ok" }
       ]
     }
   }
   ```

3. **Test Tenant Setup**
   ```bash
   # Create test tenant (SystemAdmin only)
   curl -X POST https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com/api/admin/tenants \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer <admin-token>" \
     -d '{
       "name": "Test Company Ltd",
       "subdomain": "testcompany",
       "sapDestination": "TEST_S4HANA",
       "config": {
         "modules": ["invoice-matching", "gl-anomaly", "vendor-quality", "sod-control"],
         "sapClient": "100",
         "companyCode": "1000"
       }
     }'
   ```

4. **User Setup**
   - Assign test users to role collections in BTP Cockpit
   - Verify each user can login successfully
   - Confirm role assignments are correct

---

## Test Data Preparation

### Sample Test Data

#### 1. Invoice Data (for Invoice Matching)
```json
{
  "invoices": [
    {
      "invoiceNumber": "INV-TEST-001",
      "vendorId": "VEND-001",
      "vendorName": "Test Vendor Corp",
      "invoiceDate": "2025-10-01",
      "totalAmount": 10000.00,
      "currency": "USD",
      "status": "posted"
    },
    {
      "invoiceNumber": "INV-TEST-002",
      "vendorId": "VEND-002",
      "vendorName": "Suspicious Vendor LLC",
      "invoiceDate": "2025-10-01",
      "totalAmount": 99999.99,
      "currency": "USD",
      "status": "posted"
    }
  ],
  "purchaseOrders": [
    {
      "poNumber": "PO-TEST-001",
      "vendorId": "VEND-001",
      "orderedValue": 10000.00,
      "currency": "USD"
    }
  ],
  "goodsReceipts": [
    {
      "grNumber": "GR-TEST-001",
      "poNumber": "PO-TEST-001",
      "receivedValue": 10000.00,
      "currency": "USD"
    }
  ]
}
```

#### 2. GL Transaction Data (for Anomaly Detection)
```json
{
  "transactions": [
    {
      "documentNumber": "DOC-TEST-001",
      "glAccount": "100000",
      "amount": 999999.99,
      "debitCredit": "DEBIT",
      "postingDate": "2025-10-01T23:30:00Z",
      "fiscalYear": "2025",
      "fiscalPeriod": "010"
    },
    {
      "documentNumber": "DOC-TEST-002",
      "glAccount": "200000",
      "amount": 50000.00,
      "debitCredit": "CREDIT",
      "postingDate": "2025-10-18T10:00:00Z",
      "fiscalYear": "2025",
      "fiscalPeriod": "010"
    }
  ]
}
```

#### 3. Vendor Master Data (for Data Quality)
```json
{
  "vendors": [
    {
      "vendorId": "VEND-001",
      "vendorName": "Complete Vendor Inc",
      "country": "US",
      "city": "New York",
      "postalCode": "10001",
      "street": "123 Main St",
      "taxNumber": "12-3456789",
      "bankAccount": "1234567890",
      "status": "ACTIVE"
    },
    {
      "vendorId": "VEND-DUP-001",
      "vendorName": "Acme Corporation",
      "country": "US",
      "city": "Boston",
      "taxNumber": "98-7654321",
      "status": "ACTIVE"
    },
    {
      "vendorId": "VEND-DUP-002",
      "vendorName": "ACME Corp",
      "country": "US",
      "city": "Boston",
      "taxNumber": "98-7654321",
      "status": "ACTIVE"
    },
    {
      "vendorId": "VEND-INCOMPLETE",
      "vendorName": "Incomplete Vendor",
      "country": "",
      "city": "",
      "postalCode": "",
      "taxNumber": "",
      "status": "ACTIVE"
    }
  ]
}
```

---

## Module Testing Procedures

### Test Suite 1: Invoice Matching Module

#### Test Case 1.1: Login as Finance Manager
**Tester Role**: Finance Manager
**Objective**: Verify access to Invoice Matching module

**Steps**:
1. Navigate to `https://sapmvp-test.cfapps.eu10.hana.ondemand.com`
2. Click "Login with SAP"
3. Enter credentials:
   - Username: `finance@company.com`
   - Password: `<provided-password>`
4. After login, verify redirect to dashboard
5. In the sidebar, verify "Invoice Matching" link is visible
6. Click "Invoice Matching" link

**Expected Results**:
- ✅ Login successful
- ✅ Dashboard loads
- ✅ "Invoice Matching" module visible in sidebar
- ✅ Invoice Matching dashboard loads without errors

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 1.2: Run Invoice Matching Analysis
**Tester Role**: Finance Manager
**Objective**: Execute 3-way matching analysis

**Steps**:
1. On Invoice Matching dashboard, verify you see:
   - Date range picker
   - "Run Analysis" button
   - Empty state message
2. Click date range picker
3. Select date range:
   - From: October 1, 2025
   - To: October 31, 2025
4. Click "Run Analysis" button
5. Wait for analysis to complete (loading indicator should appear)
6. Verify results appear

**Expected Results**:
- ✅ Analysis starts (loading indicator appears)
- ✅ Analysis completes within 10 seconds
- ✅ Summary cards display:
  - Total Invoices: ≥ 1
  - Matched Invoices: Number shown
  - Unmatched Invoices: Number shown
  - Match Rate: Percentage shown
- ✅ Results table displays with columns:
  - Invoice Number
  - PO Number
  - GR Number
  - Vendor
  - Amount
  - Match Status (badge: green/yellow/red)
  - Match Score
  - Actions (View Details button)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 1.3: View Match Details
**Tester Role**: Finance Manager
**Objective**: View detailed matching information

**Steps**:
1. From results table, identify an invoice with status "Partial Match"
2. Click "View Details" button for that invoice
3. Verify modal/detail panel opens
4. Review displayed information:
   - Invoice details (number, date, amount, vendor)
   - PO details (if matched)
   - GR details (if matched)
   - Discrepancies section
   - Match score breakdown

**Expected Results**:
- ✅ Detail view opens
- ✅ All invoice information displayed correctly
- ✅ Discrepancies clearly highlighted
- ✅ Match score shows breakdown by category:
  - Amount match: X%
  - Vendor match: X%
  - Date match: X%
  - Overall score: X%

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 1.4: Review Fraud Alerts
**Tester Role**: Finance Manager
**Objective**: Identify and review fraud alerts

**Steps**:
1. After running analysis, scroll to "Fraud Alerts" section
2. Verify fraud alerts card is visible if frauds detected
3. Review each alert:
   - Alert type (Duplicate, Pattern, Outlier)
   - Severity (High, Medium, Low)
   - Invoice number
   - Description
   - Evidence
4. Click "View Evidence" on a High severity alert
5. Review evidence details

**Expected Results**:
- ✅ Fraud alerts section visible (if any detected)
- ✅ Each alert shows:
  - Red/orange/yellow badge for severity
  - Clear description of issue
  - Invoice reference
  - Timestamp
- ✅ Evidence modal shows detailed analysis:
  - Why flagged as fraud
  - Supporting data
  - Recommended action

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 1.5: Export Results
**Tester Role**: Finance Manager
**Objective**: Export analysis results

**Steps**:
1. Click "Export" button in top-right corner
2. Select export format: Excel
3. Verify download starts
4. Open downloaded file
5. Verify contents:
   - Summary sheet with statistics
   - Matches sheet with all results
   - Fraud Alerts sheet (if any)

**Expected Results**:
- ✅ Export button visible and clickable
- ✅ File downloads successfully
- ✅ Excel file opens without errors
- ✅ All data present and correctly formatted
- ✅ Formulas work (if any)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 1.6: View Historical Runs
**Tester Role**: Finance Manager
**Objective**: Access previous analysis runs

**Steps**:
1. Click "History" or "Previous Runs" tab
2. Verify list of previous runs displays:
   - Run date/time
   - Date range analyzed
   - Total invoices
   - Match rate
   - Status
3. Click on a previous run
4. Verify results load

**Expected Results**:
- ✅ Historical runs list displays
- ✅ Runs sorted by date (newest first)
- ✅ Each run shows summary statistics
- ✅ Can open and view full results from past runs
- ✅ Results are read-only (cannot modify past runs)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Suite 2: GL Anomaly Detection Module

#### Test Case 2.1: Login as Finance Manager
**Tester Role**: Finance Manager
**Objective**: Access GL Anomaly Detection module

**Steps**:
1. Login as Finance Manager (finance@company.com)
2. Navigate to "GL Anomaly Detection" from sidebar
3. Verify dashboard loads

**Expected Results**:
- ✅ GL Anomaly Detection module accessible
- ✅ Dashboard displays with:
  - Fiscal year selector
  - Fiscal period selector
  - Detection method checkboxes
  - "Run Detection" button

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 2.2: Run Anomaly Detection
**Tester Role**: Finance Manager
**Objective**: Execute GL anomaly detection analysis

**Steps**:
1. On GL Anomaly Detection dashboard:
   - Select Fiscal Year: 2025
   - Select Fiscal Period: 010 (October)
   - Check detection methods:
     - ☑ Benford's Law
     - ☑ Statistical Outliers
     - ☑ After-Hours Postings
     - ☑ Duplicate Detection
2. Click "Run Detection" button
3. Wait for analysis to complete
4. Review results

**Expected Results**:
- ✅ Analysis runs successfully
- ✅ Completes within 15 seconds
- ✅ Summary section displays:
  - Total Transactions: X
  - Anomalies Found: X
  - Critical Risk: X
  - High Risk: X
  - Medium Risk: X
  - Low Risk: X
- ✅ Anomaly distribution chart shows breakdown by:
  - Detection method
  - Risk level
  - GL account
- ✅ Anomaly table displays with columns:
  - Document Number
  - GL Account
  - Amount
  - Posting Date
  - Detection Method
  - Risk Level (badge)
  - Risk Score
  - Actions

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 2.3: Review Critical Anomalies
**Tester Role**: Finance Manager
**Objective**: Investigate critical risk anomalies

**Steps**:
1. From anomaly table, click filter icon
2. Select "Risk Level: Critical"
3. Verify table filters to show only critical anomalies
4. Click on the first critical anomaly
5. Review detail panel:
   - Document details
   - GL account information
   - Amount and posting date
   - Detection method explanation
   - Evidence supporting the flag
   - Risk score breakdown
6. Click "Mark as Reviewed"
7. Add a comment: "Reviewed - legitimate transaction"
8. Save

**Expected Results**:
- ✅ Filter works correctly
- ✅ Only critical anomalies shown
- ✅ Detail panel provides comprehensive information
- ✅ Evidence clearly explains why flagged
- ✅ Risk score breakdown shows contributing factors
- ✅ Can mark as reviewed with comment
- ✅ Status updates to "Reviewed"
- ✅ Comment saved and visible

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 2.4: Analyze After-Hours Postings
**Tester Role**: Finance Manager
**Objective**: Identify suspicious after-hours transactions

**Steps**:
1. In anomaly table, click filter
2. Select "Detection Method: After-Hours Postings"
3. Sort by "Risk Score" descending
4. Review top 3 results
5. For each, verify:
   - Posting time is shown
   - Reason clearly states "Posted at [time]"
   - Weekend postings clearly marked

**Expected Results**:
- ✅ After-hours postings filtered successfully
- ✅ Each shows posting time
- ✅ Clear indication of:
  - Weekday after-hours (>18:00 or <06:00)
  - Weekend postings
  - Holiday postings (if applicable)
- ✅ Risk score higher for:
  - High amounts + after hours
  - Weekend + sensitive accounts

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 2.5: Export Anomaly Report
**Tester Role**: Finance Manager
**Objective**: Export anomaly detection report

**Steps**:
1. Click "Export Report" button
2. Select format: PDF
3. Verify download starts
4. Open PDF file
5. Verify contents:
   - Executive summary
   - Anomaly statistics
   - Charts and visualizations
   - Detailed anomaly list
   - Methodology explanation
   - Footer with timestamp and user

**Expected Results**:
- ✅ PDF exports successfully
- ✅ Professional formatting
- ✅ All sections included
- ✅ Charts render correctly
- ✅ Data matches dashboard
- ✅ Suitable for audit purposes

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Suite 3: Vendor Data Quality Module

#### Test Case 3.1: Login as Vendor Manager
**Tester Role**: Vendor Manager
**Objective**: Access Vendor Data Quality module

**Steps**:
1. Login as Vendor Manager (vendor.manager@company.com)
2. Navigate to "Vendor Data Quality" from sidebar
3. Verify dashboard loads

**Expected Results**:
- ✅ Vendor Data Quality module accessible
- ✅ Dashboard displays with:
  - Country filter
  - Status filter (Active/Blocked)
  - Quality threshold slider
  - "Run Analysis" button

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 3.2: Run Vendor Quality Analysis
**Tester Role**: Vendor Manager
**Objective**: Analyze vendor master data quality

**Steps**:
1. On Vendor Data Quality dashboard:
   - Leave all filters at default (all vendors)
   - Click "Run Analysis" button
2. Wait for analysis to complete
3. Review results

**Expected Results**:
- ✅ Analysis runs successfully
- ✅ Completes within 20 seconds
- ✅ Summary cards display:
  - Total Vendors Analyzed: X
  - Quality Issues Found: X
  - Average Quality Score: X%
  - Duplicates Found: X
  - Potential Savings: $X
- ✅ Quality distribution chart shows:
  - Score ranges (0-20%, 21-40%, etc.)
  - Issue types breakdown
  - Severity distribution
- ✅ Issues table displays with columns:
  - Vendor ID
  - Vendor Name
  - Issue Type
  - Severity
  - Field Name
  - Current Value
  - Suggested Value
  - Quality Score
  - Actions

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 3.3: Review Data Quality Issues
**Tester Role**: Vendor Manager
**Objective**: Investigate and resolve quality issues

**Steps**:
1. From issues table, filter by "Severity: High"
2. Click on first high-severity issue
3. Review detail panel showing:
   - Complete vendor information
   - Specific issue description
   - Current (incorrect) value
   - Suggested correction
   - Impact assessment
4. Click "Accept Suggestion"
5. Verify confirmation prompt
6. Confirm update
7. Verify issue marked as "Resolved"

**Expected Results**:
- ✅ High severity issues filtered correctly
- ✅ Detail panel shows comprehensive information
- ✅ Suggested value is reasonable and correct
- ✅ Can accept suggestion
- ✅ Confirmation prompt appears
- ✅ Issue status updates to "Resolved"
- ✅ (In real system: Would update SAP S/4HANA)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 3.4: Identify Duplicate Vendors
**Tester Role**: Vendor Manager
**Objective**: Find and merge duplicate vendor records

**Steps**:
1. Click "Duplicates" tab
2. Review duplicate clusters table:
   - Cluster ID
   - Number of vendors in cluster
   - Vendor IDs
   - Vendor names
   - Similarity score
   - Estimated savings
   - Actions
3. Click on a cluster with similarity score > 90%
4. Review cluster details:
   - All vendor records in cluster
   - Matching fields highlighted
   - Differences highlighted
   - Recommended master record
5. Click "Merge Cluster"
6. Select master vendor record
7. Review merge preview
8. Confirm merge

**Expected Results**:
- ✅ Duplicate clusters displayed correctly
- ✅ Clusters sorted by similarity score (highest first)
- ✅ Each cluster shows:
  - All vendors involved
  - Why flagged as duplicates
  - Estimated savings (maintenance cost reduction)
- ✅ Cluster detail view clear and comprehensive
- ✅ Can select master record
- ✅ Merge preview shows what will happen
- ✅ Merge executes successfully (in test: simulation)
- ✅ Estimated savings calculated

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 3.5: Filter by Country
**Tester Role**: Vendor Manager
**Objective**: Analyze specific country vendors

**Steps**:
1. Return to main Vendor Quality dashboard
2. In filters, select Country: "US"
3. Click "Run Analysis"
4. Verify only US vendors analyzed
5. Repeat with Country: "DE" (Germany)
6. Compare results

**Expected Results**:
- ✅ Filter applies correctly
- ✅ Results show only selected country
- ✅ Summary statistics update accordingly
- ✅ Can compare between countries
- ✅ Country-specific issues identified (e.g., postal code format)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Suite 4: SoD Control Module

#### Test Case 4.1: Login as Compliance Manager
**Tester Role**: Compliance Manager
**Objective**: Access SoD Control module

**Steps**:
1. Login as Compliance Manager (compliance@company.com)
2. Navigate to "SoD Control" from sidebar
3. Verify dashboard loads

**Expected Results**:
- ✅ SoD Control module accessible
- ✅ Dashboard displays with:
  - User ID/Name input
  - Company code selector
  - "Analyze User" button
  - Violation rules summary

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 4.2: Analyze User Roles
**Tester Role**: Compliance Manager
**Objective**: Identify segregation of duties violations

**Steps**:
1. On SoD Control dashboard:
   - Enter User ID: "TEST_USER_01"
   - Select Company Code: 1000
   - Click "Analyze User" button
2. Review results

**Expected Results**:
- ✅ Analysis completes successfully
- ✅ User information displayed:
  - User ID and name
  - Assigned roles
  - Company codes
  - Last login
- ✅ Violations section shows:
  - Total violations found
  - Critical violations
  - Each violation with:
    - Rule violated
    - Risk level
    - Conflicting roles
    - Description
    - Remediation suggestion

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

#### Test Case 4.3: Review Critical SoD Violations
**Tester Role**: Compliance Manager
**Objective**: Investigate critical violations

**Steps**:
1. From violations list, click on a "Critical" violation
2. Review violation details:
   - Rule name and ID
   - Description of conflict
   - User roles involved
   - Why it's a risk
   - Business impact
   - Recommended remediation
3. Click "Generate Remediation Report"
4. Review report content

**Expected Results**:
- ✅ Violation detail comprehensive
- ✅ Clear explanation of SoD conflict
- ✅ Specific roles identified
- ✅ Risk clearly articulated
- ✅ Actionable remediation steps provided
- ✅ Report generates successfully
- ✅ Report suitable for management/audit

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

## Integration Testing

### Test Case INT-1: Cross-Module Data Consistency
**Tester Role**: System Administrator
**Objective**: Verify data consistency across modules

**Steps**:
1. Login as SystemAdmin
2. Run Invoice Matching analysis - note Run ID
3. Navigate to API health endpoint:
   ```
   GET /api/health/database
   ```
4. Verify database tables have data
5. Query database directly (if access available):
   ```sql
   SELECT * FROM "InvoiceMatchRun" ORDER BY "runDate" DESC LIMIT 1;
   ```
6. Compare Run ID from UI with database record

**Expected Results**:
- ✅ Run ID matches between UI and database
- ✅ All related records present:
  - InvoiceMatchRun record
  - InvoiceMatchResult records
  - FraudAlert records (if any)
- ✅ Timestamps consistent
- ✅ Data integrity maintained

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Case INT-2: Navigation Flow
**Tester Role**: Finance Manager
**Objective**: Verify seamless navigation between modules

**Steps**:
1. Login as Finance Manager
2. Navigate: Dashboard → Invoice Matching
3. Run analysis
4. Navigate: Invoice Matching → GL Anomaly Detection
5. Run detection
6. Navigate: GL Anomaly Detection → Back to Dashboard
7. Navigate: Dashboard → Invoice Matching
8. Verify previous results still visible

**Expected Results**:
- ✅ All navigation links work
- ✅ No broken links or 404 errors
- ✅ Page transitions smooth
- ✅ Previous results persist (not lost on navigation)
- ✅ State management working correctly
- ✅ Browser back/forward buttons work

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Case INT-3: Multi-User Concurrent Access
**Tester Role**: Multiple users
**Objective**: Test concurrent user access

**Steps**:
1. User 1 (Finance Manager): Login and start Invoice Matching
2. User 2 (Vendor Manager): Login and start Vendor Quality analysis
3. User 3 (Compliance Manager): Login and access SoD Control
4. All users: Execute analyses simultaneously
5. Verify all complete successfully
6. Check results are user-specific (not mixed)

**Expected Results**:
- ✅ All users can login simultaneously
- ✅ All analyses run without interference
- ✅ Results are isolated by user
- ✅ No performance degradation
- ✅ No data corruption
- ✅ Each user sees only their data

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

## Security & Access Control Testing

### Test Case SEC-1: Role-Based Access Control
**Tester Role**: Various
**Objective**: Verify RBAC enforcement

**Test Matrix**:

| User Role | Invoice Matching | GL Anomaly | Vendor Quality | SoD Control | Admin |
|-----------|------------------|------------|----------------|-------------|-------|
| SystemAdmin | ✅ Full | ✅ Full | ✅ Full | ✅ Full | ✅ Full |
| ComplianceManager | ❌ No Access | ❌ No Access | ❌ No Access | ✅ Full | ❌ No Access |
| FinanceManager | ✅ Full | ✅ Full | ❌ No Access | ❌ No Access | ❌ No Access |
| Auditor | ✅ Read-Only | ✅ Read-Only | ✅ Read-Only | ✅ Read-Only | ❌ No Access |
| VendorManager | ❌ No Access | ❌ No Access | ✅ Full | ❌ No Access | ❌ No Access |

**Steps**:
1. For each user role above, login
2. Attempt to access each module
3. Verify access matches matrix
4. For "Read-Only", verify:
   - Can view dashboards
   - Can view results
   - Cannot run analyses
   - Cannot modify data
5. For "No Access", verify:
   - Module not visible in sidebar
   - Direct URL access blocked (403 error)

**Expected Results**:
- ✅ All permissions enforce correctly
- ✅ Unauthorized access blocked with appropriate error
- ✅ No security bypasses possible
- ✅ Error messages don't leak sensitive info

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Case SEC-2: Authentication Testing
**Tester Role**: Any
**Objective**: Verify authentication security

**Steps**:
1. Attempt to access app without login:
   ```
   https://sapmvp-test.cfapps.eu10.hana.ondemand.com/modules/invoice-matching
   ```
2. Verify redirect to login
3. Login with valid credentials
4. Verify redirect back to requested page
5. Wait 60 minutes (or adjust session timeout in test)
6. Attempt to perform action
7. Verify session expired message
8. Re-authenticate
9. Verify session restored

**Expected Results**:
- ✅ Unauthenticated access blocked
- ✅ Redirect to login page
- ✅ After login, redirected to original destination
- ✅ Session timeout enforced (60 min default)
- ✅ Clear message on session expiry
- ✅ Can re-authenticate without data loss

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Case SEC-3: API Security
**Tester Role**: Technical Tester
**Objective**: Verify API endpoints are secured

**Steps**:
1. Attempt API call without token:
   ```bash
   curl -X POST https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com/api/matching/analyze \
     -H "Content-Type: application/json" \
     -d '{"tenantId":"COMP-001"}'
   ```
2. Verify 401 Unauthorized response
3. Get valid auth token
4. Retry with token:
   ```bash
   curl -X POST https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com/api/matching/analyze \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer <token>" \
     -d '{"tenantId":"COMP-001"}'
   ```
5. Verify 200 OK response

**Expected Results**:
- ✅ Requests without token rejected (401)
- ✅ Requests with invalid token rejected (401)
- ✅ Requests with valid token succeed (200)
- ✅ Token includes correct user and role claims
- ✅ Rate limiting enforced (429 after limit)

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

## Performance Testing

### Test Case PERF-1: Response Time
**Tester Role**: Any
**Objective**: Verify acceptable response times

**Metrics to Measure**:

| Operation | Target Time | Measured Time | Status |
|-----------|-------------|---------------|---------|
| Login | < 2 seconds | _________ | [ ] Pass [ ] Fail |
| Dashboard Load | < 1 second | _________ | [ ] Pass [ ] Fail |
| Invoice Analysis (100 records) | < 5 seconds | _________ | [ ] Pass [ ] Fail |
| Invoice Analysis (1000 records) | < 15 seconds | _________ | [ ] Pass [ ] Fail |
| GL Anomaly Detection (1000 txns) | < 10 seconds | _________ | [ ] Pass [ ] Fail |
| Vendor Quality (100 vendors) | < 10 seconds | _________ | [ ] Pass [ ] Fail |
| Export Report (PDF) | < 3 seconds | _________ | [ ] Pass [ ] Fail |
| Health Check Endpoint | < 100 ms | _________ | [ ] Pass [ ] Fail |

**Expected Results**:
- ✅ All operations complete within target times
- ✅ No timeouts
- ✅ Loading indicators shown during processing
- ✅ User experience remains responsive

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

### Test Case PERF-2: Load Testing
**Tester Role**: Technical Tester
**Objective**: Verify system handles concurrent load

**Load Test Scenarios**:

1. **Scenario 1: Normal Load**
   - 10 concurrent users
   - Each running analyses continuously
   - Duration: 10 minutes
   - Expected: No errors, response time < 2x normal

2. **Scenario 2: Peak Load**
   - 50 concurrent users
   - Mixed operations (login, analysis, reports)
   - Duration: 15 minutes
   - Expected: Minimal errors (<1%), response time < 3x normal

3. **Scenario 3: Stress Test**
   - 100 concurrent users
   - Heavy operations (large datasets)
   - Duration: 10 minutes
   - Expected: System degrades gracefully, no crashes

**Using k6 Load Testing**:
```javascript
// Save as load-test.js
import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '2m', target: 10 },  // Ramp up to 10 users
    { duration: '5m', target: 10 },  // Stay at 10 users
    { duration: '2m', target: 50 },  // Ramp up to 50 users
    { duration: '5m', target: 50 },  // Stay at 50 users
    { duration: '2m', target: 0 },   // Ramp down to 0 users
  ],
};

export default function () {
  // Test health endpoint
  let res = http.get('https://sapmvp-api-test.cfapps.eu10.hana.ondemand.com/api/health');
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });

  sleep(1);
}
```

Run with:
```bash
k6 run load-test.js
```

**Expected Results**:
- ✅ System handles normal load easily
- ✅ Peak load causes acceptable degradation
- ✅ Stress test: system doesn't crash
- ✅ Error rate < 1% under peak load
- ✅ Response times degrade linearly (not exponentially)
- ✅ Auto-scaling triggers if configured

**Status**: [ ] Pass [ ] Fail
**Notes**: _______________________________________

---

## Expected Results Summary

### Module-Specific Expected Outcomes

#### Invoice Matching
- **Perfect Match**: Invoice amount, PO amount, and GR amount all equal
  - Match Score: 100%
  - Status: Matched (green badge)

- **Partial Match**: Minor discrepancies (e.g., rounding differences < $1)
  - Match Score: 85-99%
  - Status: Partial (yellow badge)

- **Unmatched**: Major discrepancies or missing documents
  - Match Score: < 85%
  - Status: Unmatched (red badge)

- **Fraud Alerts**:
  - Duplicate invoices: Same amount, vendor, within 7 days
  - Outlier amounts: > 3 standard deviations from average
  - Pattern anomalies: Unusual sequences or timing

#### GL Anomaly Detection
- **Benford's Law**: First digit distribution deviates > 15% from expected
- **Statistical Outliers**: Amount > 3 standard deviations from account mean
- **After-Hours**: Postings between 18:00-06:00 weekdays, or weekends
- **Duplicates**: Same account, amount, date within 1 hour
- **Risk Scoring**:
  - Critical: 90-100 (immediate investigation)
  - High: 70-89 (review within 24h)
  - Medium: 50-69 (review within week)
  - Low: < 50 (informational)

#### Vendor Data Quality
- **Quality Score Calculation**:
  - 100%: All required fields complete and valid
  - 80-99%: Missing non-critical fields
  - 60-79%: Missing critical fields or format issues
  - < 60%: Multiple critical issues, high risk

- **Duplicate Detection**:
  - Exact match: Same name + tax ID (100% similarity)
  - High confidence: Same tax ID or bank account (> 90%)
  - Medium confidence: Similar name + same address (70-90%)
  - Low confidence: Similar name only (< 70%)

- **Estimated Savings**:
  - $500 per duplicate vendor (maintenance cost reduction)
  - Calculated as: Number of duplicate vendors × $500

#### SoD Control
- **Violation Types**:
  - Create + Approve: User can create and approve same transaction
  - Execute + Reconcile: User can execute and reconcile same process
  - Custody + Record: User has custody and recording access

- **Risk Levels**:
  - Critical: Direct fraud opportunity
  - High: Significant control weakness
  - Medium: Control gap, mitigated by other controls
  - Low: Theoretical risk only

---

## Test Reporting

### Test Execution Report Template

```
=================================================================
SAP MVP FRAMEWORK - TEST EXECUTION REPORT
=================================================================

Test Date: __________________
Tester Name: __________________
Environment: [ ] Staging [ ] Production [ ] Development

-----------------------------------------------------------------
TEST SUMMARY
-----------------------------------------------------------------
Total Test Cases: _______
Passed: _______
Failed: _______
Blocked: _______
Not Executed: _______

Pass Rate: _______%

-----------------------------------------------------------------
MODULE TESTING RESULTS
-----------------------------------------------------------------

Invoice Matching Module:
  Total Cases: _______  Passed: _______  Failed: _______
  Critical Issues: _______________________________________

GL Anomaly Detection Module:
  Total Cases: _______  Passed: _______  Failed: _______
  Critical Issues: _______________________________________

Vendor Data Quality Module:
  Total Cases: _______  Passed: _______  Failed: _______
  Critical Issues: _______________________________________

SoD Control Module:
  Total Cases: _______  Passed: _______  Failed: _______
  Critical Issues: _______________________________________

-----------------------------------------------------------------
SECURITY TESTING RESULTS
-----------------------------------------------------------------
Authentication: [ ] Pass [ ] Fail
Authorization (RBAC): [ ] Pass [ ] Fail
API Security: [ ] Pass [ ] Fail
Session Management: [ ] Pass [ ] Fail

Security Issues Found: _______________________________________

-----------------------------------------------------------------
PERFORMANCE TESTING RESULTS
-----------------------------------------------------------------
Response Time Tests: [ ] Pass [ ] Fail
Load Testing (10 users): [ ] Pass [ ] Fail
Load Testing (50 users): [ ] Pass [ ] Fail
Stress Testing: [ ] Pass [ ] Fail

Performance Issues: _______________________________________

-----------------------------------------------------------------
CRITICAL ISSUES
-----------------------------------------------------------------
1. ___________________________________________________________
   Severity: [ ] Critical [ ] High [ ] Medium [ ] Low
   Status: [ ] Open [ ] Resolved [ ] Deferred

2. ___________________________________________________________
   Severity: [ ] Critical [ ] High [ ] Medium [ ] Low
   Status: [ ] Open [ ] Resolved [ ] Deferred

-----------------------------------------------------------------
RECOMMENDATIONS
-----------------------------------------------------------------
1. ___________________________________________________________
2. ___________________________________________________________
3. ___________________________________________________________

-----------------------------------------------------------------
SIGN-OFF
-----------------------------------------------------------------
Production Deployment Recommendation: [ ] Approve [ ] Reject

Tester Signature: ______________________  Date: __________

QA Manager: ______________________  Date: __________

Product Owner: ______________________  Date: __________

=================================================================
```

---

## Troubleshooting Common Issues

### Issue 1: Cannot Login
**Symptoms**: Login button doesn't respond, or redirects to error page
**Possible Causes**:
- XSUAA service not bound
- User not assigned to role collection
- Network connectivity issue

**Resolution**:
1. Verify user email in BTP Cockpit → Security → Users
2. Check role collections assigned
3. Verify XSUAA service is running: `cf service sapmvp-xsuaa`
4. Check application logs: `cf logs sapmvp-api --recent | grep XSUAA`

---

### Issue 2: Analysis Doesn't Complete
**Symptoms**: Loading indicator runs indefinitely, or timeout error
**Possible Causes**:
- Database connection issue
- SAP S/4HANA connection timeout
- Large dataset causing timeout

**Resolution**:
1. Check database health: `curl .../api/health/database`
2. Verify SAP destination configured correctly
3. Try smaller date range
4. Check API logs for errors
5. Increase timeout in test environment if needed

---

### Issue 3: Results Don't Load
**Symptoms**: Analysis completes but results section empty
**Possible Causes**:
- No data found for criteria
- Database query error
- Frontend state management issue

**Resolution**:
1. Verify test data exists for selected criteria
2. Check browser console for JavaScript errors
3. Check network tab for failed API calls
4. Verify database has records: `SELECT COUNT(*) FROM "InvoiceMatchRun"`
5. Try refreshing browser (Ctrl+F5)

---

## Test Data Cleanup

After testing, clean up test data:

```sql
-- Delete test runs (adjust dates as needed)
DELETE FROM "InvoiceMatchResult" WHERE "runId" IN (
  SELECT id FROM "InvoiceMatchRun" WHERE "tenantId" = 'TEST-TENANT'
);
DELETE FROM "FraudAlert" WHERE "runId" IN (
  SELECT id FROM "InvoiceMatchRun" WHERE "tenantId" = 'TEST-TENANT'
);
DELETE FROM "InvoiceMatchRun" WHERE "tenantId" = 'TEST-TENANT';

-- Repeat for other modules
DELETE FROM "GLAnomaly" WHERE "runId" IN (
  SELECT id FROM "GLAnomalyRun" WHERE "tenantId" = 'TEST-TENANT'
);
DELETE FROM "GLAnomalyRun" WHERE "tenantId" = 'TEST-TENANT';

DELETE FROM "VendorQualityIssue" WHERE "runId" IN (
  SELECT id FROM "VendorQualityRun" WHERE "tenantId" = 'TEST-TENANT'
);
DELETE FROM "VendorDuplicateCluster" WHERE "runId" IN (
  SELECT id FROM "VendorQualityRun" WHERE "tenantId" = 'TEST-TENANT'
);
DELETE FROM "VendorQualityRun" WHERE "tenantId" = 'TEST-TENANT';

-- Delete test tenant
DELETE FROM "Tenant" WHERE subdomain = 'testcompany';
```

---

## Appendix: Quick Reference

### User Credentials Summary
```
SystemAdmin:         admin@sapmvp.com
ComplianceManager:   compliance@company.com
FinanceManager:      finance@company.com
Auditor:             auditor@company.com
VendorManager:       vendor.manager@company.com
```

### API Endpoints Quick Reference
```
Health:              GET  /api/health
Database Health:     GET  /api/health/database
Invoice Matching:    POST /api/matching/analyze
                     GET  /api/matching/runs
GL Anomaly:          POST /api/modules/gl-anomaly/detect
                     GET  /api/modules/gl-anomaly/runs
Vendor Quality:      POST /api/modules/vendor-quality/analyze
                     GET  /api/modules/vendor-quality/runs
SoD Control:         POST /api/modules/sod/analyze
```

### Expected Response Times
```
Health Check:        < 100ms
Login:               < 2s
Dashboard Load:      < 1s
Small Analysis:      < 5s
Medium Analysis:     < 15s
Large Analysis:      < 30s
Report Export:       < 3s
```

---

**Document Version**: 1.0
**Last Updated**: October 13, 2025
**Next Review**: Post-UAT

---

**End of Testing Guide**
